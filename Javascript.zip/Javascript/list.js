function checkItem(){
   var d;
   var txtValue,filter;
  var a=  document.getElementById("fetch").value;
 filter= a.toUpperCase();
 var b=document.getElementById("list");

      var c=b.getElementsByTagName("li");
   

      for(i=0;i<c.length;i++){
          d=c[i].getElementsByTagName("a")[0];
        //console.log( d.textContent +" Helloooo")
        txtValue=d.innerText;
     if(txtValue.toUpperCase().indexOf(filter)>-1)
     {
       c[i].style.display="";
     }
     else{
      c[i].style.display="none";
     }
      
     
      }
}
 document.getElementsByTagName("a").addEventListner("onmouseover" ,getLite);

 function getLite(){
    document.getElementsByTagName("a").style.background='gray';
 }


 document.getElementById("checkbx").addEventListener("click", function(event){
    event.preventDefault();
 });
function storeSearch(){
   var x=document.getElementById("fetch").value;
   x.style.background
   document.getElementById("para").innerHTML=x;
     
}