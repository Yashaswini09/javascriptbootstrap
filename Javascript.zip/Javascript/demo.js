function myFunction(){
 
   document.getElementById("demo").style.background='red';
}

function  linkActive(){
    document.getElementById("anchr").style.color='darkolivegreen'
}
function getCancel(){
    document.getElementById("dem").style.display='none'
}

document.getElementById("dem").onclick=function(){
    window.location.href="";
}

function getMaroon(){
    document.getElementById("demo").style.background='red';
}
function getMarr(){
document.getElementById("demo").style.background='maroon';
}
function getData()
{
   var username= document.getElementById("user_input").value
    var pwd=document.getElementById("pwd").value
    alert(username+" "+pwd)
    // alert(document.getElementsByClassName("form-control").value)
    var use=document.getElementById("user_input").value='';
    var pd=document.getElementById("pwd").value='';
  
  
       document.getElementById("user_input").style.background='white'
       document.getElementById("pwd").style.background='white'
   
 
}

document.getElementById("user_input").addEventListener('keypress',presskey);
function presskey(){
    document.getElementById("user_input").style.background='wheat';
}
document.getElementById("pwd").addEventListener('keypress',presskey1);
function presskey1(){
    document.getElementById("pwd").style.background='wheat';
}
function getDate(){
    var d= new Date();
    document.getElementById("date").innerHTML=d;

}
function getBlur(){
   var x= document.getElementById("user_input").value;
        x.style.color='maroon';
        var y= document.getElementById("pwd").value;
        y.toUpperCase();
}
function drag(event){
    event.dataTransfer.setData("text",event.target.id);
}
function drop(event)
{ev.preventDefault();
    var data=event.dataTransfer.getData("text")
    event.target.appendChild(document.getElementById("data"))
}
function allowDrop(ev) {
    ev.preventDefault();
  }
  
  function getRed(){
      document.getElementById("regis").style.background='red';
  }
  function getDefaul(){
      document.getElementById("regis").style.background='maroon';
  }
  document.getElementById("check").addEventListener('click',getGreen)
  function getGreen(){
      document.getElementById("check").style.background='green';
  }

  /*Form Validation */

  function validateForm()
  {
   var attempt =1;
      var a=document.getElementById("user_input").value
      var b=document.getElementById("pwd").value

      if(a=='' && b==''){
          alert("Please insert the username and password");
      }
      if(a=="Sneha@123" && b=="Tanvi@123")
      {
          alert("Successfully accepted");
      }
      else{
          attempt --;
          alert("You are left with "+attempt+" attempts")
          if(attempt==0)
          {
              document.getElementById("user_input").disabled=true;
              document.getElementById("pwd").disabled=true;
              document.getElementById("demo").disabled=true;
              document.getElementById("dem").disabled=true;
              return false;
          }
      }
  }