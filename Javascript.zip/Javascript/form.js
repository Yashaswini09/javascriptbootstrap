function getSubmit(){
    var a= document.getElementById("user").value;
    var b= document.getElementById("pwd").value ;

    if(a=="" && b=="")
    {
       document.getElementById("validationServer01").innerHTML="Please Fill!!!";
       document.getElementById("validationServer02").innerHTML="Please Fill!!!";
    }
    else{
        document.getElementById("user").value ='';
        document.getElementById("pwd").value='' ;
        document.getElementById("user").style.background="white";
        document.getElementById("pwd").style.background="white";


    }
}