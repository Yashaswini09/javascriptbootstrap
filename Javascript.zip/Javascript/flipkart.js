function onpress()
{
    var a=document.getElementById("drop");
     var b= a.getElementsByTagName("li");
            console.log(b.innertext);
    
}

function checkItem(){
    var c,txtValue;
    var d=document.getElementById("form").value;
    var filter=d.toUpperCase()

    var ul=document.getElementById("list");

    var li=ul.getElementsByTagName("li");
    for(i=0;i<li.length;i++){
        c=li[i].getElementsByTagName("a")[0];
      txtValue= c.textContent;
      
      if(txtValue.toUpperCase().indexOf(filter)==0){
     
          
           li[i].style.display="";
      }
      else{
          li[i].style.display="none";
      }
    }
    }

    function isSorted(){
        var switching,shouldswitch;
        switching=true;
        var list= document.getElementById("list");
        console.log(list)
        while(switching)
        {
            switching=false;
       var li= list.getElementsByTagName("li")
       for(i=0;i<(li.length-1);i++)
       {
        switching=false;
         if(li[i].innerHTML.toLowerCase()>li[i+1].innerHTML.toLowerCase()){
             shouldswitch=true;
             break;
         }
       }
       if (shouldswitch)
       {
        li[i].parentNode.insertBefore(li[i+1],li[i])
        switching=true;
       }
    }
}
function getActive(){
    var i;
 var b=document.getElementById("list");
  var c =b.getElementsByTagName("li");
  for( i=0;i<c.length;i++){
      c[i].addEventListener("click", function(){
          var current=document.getElementsByClassName("active");
          current[0].className=current[0].className.replace("active","");
         this.className=this.className+"active"
      })
  }
}
function getData(){
    var newText=document.createElement("LI");
    var textCon=document.createTextNode("Lipstick");
    newText.appendChild(textCon);

    var ul=document.getElementById("list");
    ul.insertBefore(newText,ul.childNodes[2]);
}

